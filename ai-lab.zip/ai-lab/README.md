# AI-LAB

Code for the AI lab course 2018/2019 of the University of Verona

Environments are based on OpenAI Gym: https://github.com/openai/gym